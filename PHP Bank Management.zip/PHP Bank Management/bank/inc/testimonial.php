<div data-vide-bg="video/coins">
	<div class="stats center-container" id="stats">
		<div class="container">
			<div class="stats-info">
				<div class="col-md-4 col-xs-4 stats-grid slideanim">
					<i class="fa fa-user-o" aria-hidden="true"></i>
					<div class="agile-one">
						<h4 class="stats-info">Employees</h4>
						<div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='12760' data-delay='.5' data-increment="1">12760</div>
					</div>
				</div>
				<div class="col-md-4 col-xs-4 stats-grid slideanim">
					<i class="fa fa-globe" aria-hidden="true"></i>
					<div class="agile-one">
						<h4 class="stats-info">Locations</h4>
						<div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='12760' data-delay='.5' data-increment="1">12760</div>
					</div>
				</div>
				<div class="col-md-4 col-xs-4 stats-grid slideanim">
					<i class="fa fa-diamond" aria-hidden="true"></i>
					<div class="agile-one">
						<h4 class="stats-info">Awards Winning</h4>
						<div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='12760' data-delay='.5' data-increment="1">12760</div>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</div>
</div>
<!--//stats-->
<!-- team -->
	<div id="team" class="team agileits">
		<div class="team-agileinfo">
			<div class="container">  
				<h3 class="w3l-title"><span>Our</span> Team</h3>
				<div class="team-row agileits-w3layouts">
					<div class="col-md-3 col-xs-6 team-grids">
						<div class="team-agileimg">
							<img class="img-responsive" src="images/t1.jpg" alt="">
							<div class="captn">
								<div class="captn-top">
									<h4>Mark Sophia </h4>
									<p>Aenean ac enimet tincidunt Utin tincidunt</p>
								</div> 
								<div class="social-w3lsicon agileinfo-social-grids">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-rss"></i></a></li> 
									</ul>
								</div> 
							</div>
						</div>
					</div>					
					<div class="col-md-3 col-xs-6 team-grids">
						<div class="team-agileimg">
							<img class="img-responsive" src="images/t2.jpg" alt="">
							<div class="captn">
								<div class="captn-top">
									<h4>Edwards Doe</h4>
									<p>Aenean ac enimet tincidunt Utin tincidunt</p>
								</div>
								<div class="social-w3lsicon agileinfo-social-grids">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-rss"></i></a></li> 
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-xs-6 team-grids">
						<div class="team-agileimg">
							<img class="img-responsive" src="images/t3.jpg" alt="">
							<div class="captn">
								<div class="captn-top">
									<h4>Michael amet</h4>
									<p>Aenean ac enimet tincidunt Utin tincidunt</p>
								</div>
								<div class="social-w3lsicon agileinfo-social-grids">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-rss"></i></a></li> 
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-xs-6 team-grids">
						<div class="team-agileimg">
							<img class="img-responsive" src="images/t4.jpg" alt="">
							<div class="captn">
								<div class="captn-top">
									<h4>Daniel Nyari</h4>
									<p>Aenean ac enimet tincidunt Utin tincidunt</p>
								</div>
								<div class="social-w3lsicon agileinfo-social-grids">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-rss"></i></a></li> 
									</ul>
								</div> 
							</div>
						</div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
	</div>
	<!-- //team -->   
