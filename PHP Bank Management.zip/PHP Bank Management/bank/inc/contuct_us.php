<!-- mail -->
<div class="mail" id="contact">
	<div class="container">
		<h3 class="w3l-title"><span>Contact</span> Us</h3>
		<div class="mail-w3l-agile">
			<div class="col-md-6 col-sm-6 contact-left-w3ls">
				<div class="w3l-cont-mk">
					<img src="images/img2.jpg">
				</div>
				<h3>Contact Info</h3>
				<div class="visit">
					<div class="col-md-2 col-sm-2 col-xs-2 contact-icon-wthree">
						<i class="fa fa-home" aria-hidden="true"></i>
					</div>
					<div class="col-md-10 col-sm-10 col-xs-10 contact-text-agileinf0">
						<h4>Visit us</h4>
                                                <h2>একতা সঞ্চয় ও ঋণদান সমবায় সমিতি লিঃ</h2>
						<p>Nikrail Bazar, Nikrail, Bhuapur, Tangail.</p>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="mail-w3">
					<div class="col-md-2 col-sm-2 col-xs-2 contact-icon-wthree">
						<i class="fa fa-envelope-o" aria-hidden="true"></i>
					</div>
					<div class="col-md-10 col-sm-10 col-xs-10 contact-text-agileinf0">
						<h4>Mail us</h4>
						<p><a href="mailto:info@example.com">info@example.com</a></p>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="call">
					<div class="col-md-2 col-sm-2 col-xs-2 contact-icon-wthree">
						<i class="fa fa-phone" aria-hidden="true"></i>
					</div>
					<div class="col-md-10 col-sm-10 col-xs-10 contact-text-agileinf0">
						<h4>Call us</h4>
						<p>01722830546</p>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="col-md-6 col-sm-6 agileinfo_mail_grid_right">
				<h3>Get In Touch</h3>
				<form action="#" method="post">
					<div class="wthree_contact_left_grid">
						<input type="text" name="Name" placeholder="Name" required="">
						<input type="email" name="Email" placeholder="Email" required="">
						<input type="text" name="number" placeholder="Phone Number" required="">
					</div>
					<textarea name="Message" placeholder="Message......." required=""></textarea>
					<input type="submit" value="Submit">
				</form>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<div class="map">
	<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d1299.751945771892!2d89.84381616548761!3d24.4022058979989!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e1!3m2!1sen!2sbd!4v1523510737000" width="800" height="600" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
<!-- //mail -->