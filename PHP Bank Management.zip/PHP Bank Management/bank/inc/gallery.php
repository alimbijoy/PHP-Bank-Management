<!--/gallery-->
 <div class="gallery" id="gallery">
	<div class="container">
		<h3 class="w3l-title"><span>Our</span> Gallery</h3>
		<div class="agile_gallery_grids w3-agile">
				<ul class="clearfix demo">
					<li>
						<div class="gallery-grid1">
							<img src="images/g1.jpg" alt=" " class="img-responsive" />
							<div class="p-mask">
								<h4><span>Online</span> Banking</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="gallery-grid1">
							<img src="images/g2.jpg" alt=" " class="img-responsive" />
							<div class="p-mask">
								<h4><span>Online</span> Banking</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="gallery-grid1">
							<img src="images/g3.jpg" alt=" " class="img-responsive" />
							<div class="p-mask">
								<h4><span>Online</span> Banking</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="gallery-grid1">
							<img src="images/g4.jpg" alt=" " class="img-responsive" />
							<div class="p-mask">
								<h4><span>Online</span> Banking</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="gallery-grid1">
							<img src="images/g5.jpg" alt=" " class="img-responsive" />
							<div class="p-mask">
								<h4><span>Online</span> Banking</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="gallery-grid1">
							<img src="images/g6.jpg" alt=" " class="img-responsive" />
							<div class="p-mask">
								<h4><span>Online</span> Banking</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="gallery-grid1">
							<img src="images/g7.jpg" alt=" " class="img-responsive" />
							<div class="p-mask">
								<h4><span>Online</span> Banking</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="gallery-grid1">
							<img src="images/g8.jpg" alt=" " class="img-responsive" />
							<div class="p-mask">
								<h4><span>Online</span> Banking</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum.</p>
							</div>
						</div>
					</li>
					<li>
						<div class="gallery-grid1">
							<img src="images/g9.jpg" alt=" " class="img-responsive" />
							<div class="p-mask">
								<h4><span>Online</span> Banking</h4>
								<p>Neque porro quisquam est, qui dolorem ipsum.</p>
							</div>
						</div>
					</li>
				</ul>
			</div>
	</div>
</div>
<!--//gallery-->