
<?php

$filepath = realpath(dirname(__FILE__));
 include_once($filepath.'/../lib/Session.php');
 include_once($filepath.'/../lib/Database.php');
 include_once($filepath.'/../helpers/Format.php');
Session::checkLogin();
 	
  ?>



<?php
	/**
	* Admin login class
	*/
	class Adminlogin{

		private $db;
		private $fm;

		function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}

		public function adminLogin($mobile, $adminPassword){
			$mobile        = $this->fm->validation($mobile);
			$adminPassword = $this->fm->validation($adminPassword);

			$mobile        = mysqli_real_escape_string($this->db->link, $mobile);
			$adminPassword = mysqli_real_escape_string($this->db->link, md5($adminPassword));

			if (empty($mobile) || empty($adminPassword)) {
				$loginmsg = "Mobile number or password must not be empty!";
				return $loginmsg;
			}else{
				$query = "SELECT * FROM tbl_user WHERE mobile='$mobile' AND adminPassword='$adminPassword'";
				$result = $this->db->select($query);

				if ($result != FALSE) {
					$value = $result->fetch_assoc();
					Session::set('adminLogin', true);
					Session::set('adminId', $value['adminId']);
					Session::set('userName', $value['userName']);
					Session::set('adminName', $value['adminName']);
					Session::set('image', $value['image']);
					Session::set('adminPassword', $value['adminPassword']);
                                        Session::set('adminRole', $value['adminRole']);
					header("Location:index.php");
				}else{
					$loginmsg = "Username or password not match!";
				return $loginmsg;
				}
			}
		}

                public function addUser($userName, $adminName, $date){
                $query = "INSERT INTO tbl_user(userName, adminName, $date) VALUES('$userName', '$adminName', '$date')";
                $inserted_row = $this->db->insert($query);
                }




	}

 ?>