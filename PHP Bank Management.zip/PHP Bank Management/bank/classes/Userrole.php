<?php
 $filepath = realpath(dirname(__FILE__));
 include_once($filepath.'/../lib/Database.php');
 include_once($filepath.'/../helpers/Format.php');
 	
  ?>

<?php

class Userrole{
	
	private $db;
	private $fm;

	function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
	}
        
        
        public function addUser($data, $file){
            
        $userName        = $this->fm->validation($data['userName']);
        $adminName       = $this->fm->validation($data['adminName']);
        $adminPassword   = $this->fm->validation($data['adminPassword']);
        $mobile          = $this->fm->validation($data['mobile']);
        $adminRole       = $this->fm->validation($data['adminRole']);

          
           $userName        = mysqli_real_escape_string($this->db->link, $data['userName']);
           $adminName       = mysqli_real_escape_string($this->db->link, $data['adminName']);
           $adminPassword   = mysqli_real_escape_string($this->db->link, md5($data['adminPassword']));
           $mobile          = mysqli_real_escape_string($this->db->link, $data['mobile']);
           $adminRole       = mysqli_real_escape_string($this->db->link, $data['adminRole']);
           
        $permited  = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $file['image']['name'];
        $file_size = $file['image']['size'];
        $file_temp = $file['image']['tmp_name'];
        
       
        
        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image_name = substr(md5(time()), 0, 10).'.'.$file_ext;
        $uploaded_image = "upload/".$unique_image_name;
        
         if(empty($userName)|| empty($adminName)|| empty($uploaded_image) || empty($adminPassword)|| empty($mobile)|| empty($adminRole)){			    	
          $msg = "<span style=color:red;>Field must not empty!</span>";
          return $msg;    
         }elseif(empty($file_name)) {
         $msg = "<span class='error'>Please select a image</span>";
         return $msg;
          }elseif ($file_size >1048567) {
              $msg = "<span class='error'>Image size should be less then 1 mb!</span>";
              return $msg;
          }elseif (in_array($file_ext, $permited) === false) {
              $msg = "<span class='error'>you can upload only:-".implode(', ', $permited)."</span>";
              return $msg;

        }else {          
              move_uploaded_file($file_temp, $uploaded_image);       
            $query = "INSERT INTO tbl_user(userName, adminName, image, adminPassword, mobile, adminRole) VALUES('$userName', '$adminName','$uploaded_image', '$adminPassword','$mobile','$adminRole')";
            $inserted_row = $this->db->insert($query);
            if ($inserted_row) {
                    $msg = "<span style='color:green'>User inserted Successfully</span>";
                    return $msg;
            }else{
                    $msg = "<span style='color:red'>User not inserted Successfully</span>";
                    return $msg;
              }
              
        }  


      }
      
    public function getUserById($id){
     $query = "SELECT * FROM tbl_user WHERE adminId='$id'";
     $result = $this->db->select($query);     
     return $result;
     }
     
     public function getAllUser(){
     $query = "SELECT * FROM tbl_user";
     $result = $this->db->select($query);     
     return $result;  
     }
     
     public function delUser($id){
      $query = "DELETE FROM tbl_user WHERE adminId = '$id'";
      $result = $this->db->delete($query);
      return $result;
     }
     
     public function selectAllUser($id){
     $query = "SELECT * FROM tbl_user WHERE adminId='$id'";
     $result = $this->db->select($query);     
     return $result;     
     }
     
     
     public function updateUser($data, $file, $id){
        $userName        = $this->fm->validation($data['userName']);
        $adminName       = $this->fm->validation($data['adminName']);
        $mobile          = $this->fm->validation($data['mobile']);
        $adminRole       = $this->fm->validation($data['adminRole']);


       $userName        = mysqli_real_escape_string($this->db->link, $data['userName']);
       $adminName       = mysqli_real_escape_string($this->db->link, $data['adminName']);
       $mobile          = mysqli_real_escape_string($this->db->link, $data['mobile']);
       $adminRole       = mysqli_real_escape_string($this->db->link, $data['adminRole']); 
       

       
       
        $permited  = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $file['image']['name'];
        $file_size = $file['image']['size'];
        $file_temp = $file['image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
        $uploaded_image = "upload/".$unique_image;
        
      
        

        
        

        if ($userName == "" || $adminName == "" || $mobile == "" || $adminRole == "" ) {
             $msg = "<span class='error'>Field must not be empty!</span>";
             return $msg;

        }else{


     if (!empty($file_name)) {
                        
            if ($file_size >1048567) {
             $msg = "<span class='error'>Image Size should be less then 1MB!</span>";
             return $msg;
             
            } elseif (in_array($file_ext, $permited) === false) {
             $msg =  "<span class='error'>You can upload only:-".implode(', ', $permited)."</span>";
             return $msg;
            } else{
//          extra
             $query = "select * from tbl_user where adminId='$id'";
	        $getImg = $this->db->select($query);

	         if ($getImg) {
	         	while( $imgdata = $getImg->fetch_assoc()) { 
	         	$delimg = $imgdata['image'];
                        
                            unlink($delimg);  
                        
                      

	           }
	         }      
//          extra
          move_uploaded_file($file_temp, $uploaded_image);
          $query ="UPDATE tbl_user
                    SET
                    userName     = '$userName',
                    adminName    = '$adminName',
                   image         = '$uploaded_image',
                    mobile       = '$mobile',
                    adminRole    = '$adminRole'
                    
                     WHERE adminId = '$id' "; 

   
            $updeted_row = $this->db->update($query);
            if ($updeted_row) {
             $msg = "<span class='success'>Data Updated Successfully.</span>";
             return $msg;
             
            }else {
             $msg = "<span class='error'>Data Not Updated !</span>";
             return $msg;
            }
        }

     }
 
   }

       
  }
  

    
        

	


}	