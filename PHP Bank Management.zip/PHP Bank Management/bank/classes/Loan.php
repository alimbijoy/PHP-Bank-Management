<?php
 $filepath = realpath(dirname(__FILE__));
 include_once($filepath.'/../lib/Database.php');
 include_once($filepath.'/../helpers/Format.php');
 	
  ?>

<?php

class Loan{
	
	private $db;
	private $fm;

	function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
	}
        
        public function addLoan($data, $customerId){
          $loanType       = $this->fm->validation($data['loanType']);
          $amount         = $this->fm->validation($data['amount']);
          $loanNumbber    = $this->fm->validation($data['loanNumbber']);
          $munafa         = $this->fm->validation($data['munafa']);
          $inTotal        = $this->fm->validation($data['inTotal']);
          $startDate      = $this->fm->validation($data['startDate']);
          $endDate        = $this->fm->validation($data['endDate']);
          $kisti          = $this->fm->validation($data['kisti']);
          $totalKisti     = $this->fm->validation($data['totalKisti']);
          $loanBima       = $this->fm->validation($data['loanBima']);
          $grantedName    = $this->fm->validation($data['grantedName']);
          $grantedMobile  = $this->fm->validation($data['grantedMobile']);
          $relation       = $this->fm->validation($data['relation']);
          
          if(empty($loanType)|| empty($amount)|| empty($loanNumbber)|| empty($munafa)|| empty($inTotal)||
            empty($totalKisti)|| empty($loanBima)|| empty($grantedName)|| empty($grantedMobile)|| empty($relation)){
            $msg = "<span style=color:red;>Field must not empty!</span>";
            return $msg;  
              
          } else {
                 $query = "INSERT INTO tbl_loan
                     (loanType, amount, loanNumbber, munafa, inTotal, startDate, 
                     endDate, kisti, totalKisti, loanBima, grantedName, grantedMobile, relation, customerId)
                      VALUES
                     ('$loanType','$amount','$loanNumbber', '$munafa','$inTotal', '$startDate','$endDate','$kisti',
                         '$totalKisti','$loanBima', '$grantedName', '$grantedMobile', '$relation','$customerId')";
             
            
                   $inserted_row = $this->db->insert($query);
                   if ($inserted_row) {
                    $msg = "<span style='color:#ffff;'>Loan inserted Successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'> Loan not inserted Successfully</span>";
                    return $msg;
              }
              
              
          }

        }
        
        
        public function selectLoanbayid($customerId){
         $query ="SELECT * FROM tbl_loan WHERE customerId='$customerId'"; 
         $result = $this->db->select($query);
         return $result;  
        }

        







        public function updateLoan($data, $customerId){
          $loanType      = $this->fm->validation($data['loanType']);
          $amount         = $this->fm->validation($data['amount']);
          $loanNumbber    = $this->fm->validation($data['loanNumbber']);
          $munafa         = $this->fm->validation($data['munafa']);
          $inTotal        = $this->fm->validation($data['inTotal']);
          $startDate      = $this->fm->validation($data['startDate']);
          $endDate        = $this->fm->validation($data['endDate']);
          $kisti          = $this->fm->validation($data['kisti']);
          $totalKisti     = $this->fm->validation($data['totalKisti']);
          $loanBima       = $this->fm->validation($data['loanBima']);
          $grantedName    = $this->fm->validation($data['grantedName']);
          $grantedMobile  = $this->fm->validation($data['grantedMobile']);
          $relation       = $this->fm->validation($data['relation']);
          
          if(empty($loanType)|| empty($amount)|| empty($loanNumbber)|| empty($munafa)|| empty($inTotal)||
            empty($totalKisti)|| empty($loanBima)|| empty($grantedName)|| empty($grantedMobile)|| empty($relation)){
            $msg = "<span style=color:red;>Field must not empty!</span>";
            return $msg;  
              
          } else {
                $query ="UPDATE tbl_loan
                    SET
                    loanType     = '$loanType',
                    amount       = '$amount',
                   loanNumbber   = '$loanNumbber',
                    munafa       = '$munafa',
                    inTotal      = '$inTotal',
                    startDate    = '$startDate',
                    endDate      = '$endDate',
                    kisti        = '$kisti',
                    totalKisti   = '$totalKisti', 
                    loanBima     = '$loanBima',
                    grantedName  = '$grantedName', 
                    grantedMobile= '$grantedMobile', 
                    relation     = '$relation'
                     

                 WHERE customerId = '$customerId'"; 
                
                   $updated_row = $this->db->update($query);
                   if ($updated_row) {
                    $msg = "<span style='color:#ffff;'>Loan update Successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'> Loan not update Successfully</span>";
                    return $msg;
              }
              
              
          } 
        }

        



        public function getLoanById($id){
         $query ="SELECT * FROM tbl_loan WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;  
       }
       
       public function getgeneralSonchoy($id){
         $query ="SELECT * FROM tbl_general_sonchoy WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function getsthayisonchoy($id){
         $query ="SELECT * FROM tb_sthayi_sonchoy WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;  
       }
       
        public function getallbima($id){
         $query ="SELECT * FROM tbl_bima WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;  
       }
       
       public function getadayById($id){
         $query ="SELECT sum(kistiaday), COUNT(*) FROM `tbl_kisti_aday` WHERE customerId =$id";
         $result = $this->db->select($query);
         return $result;

       }
       
       public function getintotalamo($id){
        $query ="SELECT sum(inTotal), COUNT(*) FROM `tbl_loan` WHERE customerId =$id";
         $result = $this->db->select($query);
         return $result;   
       }

       

       public function getnumberkisti($id){
         $query ="SELECT * FROM tbl_kisti_aday WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;   
       }
       
       public function getstahisonchoy($id){
         $query ="SELECT sum(sthayiaday), COUNT(*) FROM `btl_sthayi_sonchoy_aday` WHERE customerId =$id "; 
         $result = $this->db->select($query);
         return $result;  
       }
       
       public function getpsavingpayment($id){
         $query ="SELECT * FROM `btl_sthayi_sonchoy_aday` WHERE customerId ='$id'"; 
         $result = $this->db->select($query);
         return $result;  
       }
       
       public function getpsavingprofit($id){
        $query ="SELECT * FROM `tbl_psaving_profit` WHERE customerId ='$id'"; 
         $result = $this->db->select($query);
         return $result;     
       }
      
       public function psrofitinsert($id, $psprofit){
          $query = "INSERT INTO tbl_psaving_profit
                     (customerId, psprofit)
                      VALUES
                     ('$id','$psprofit')";
            
                    $inserted_row = $this->db->insert($query);
                    if ($inserted_row) {
                    $msg = "<span style='color:#000'>Insert  successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'>Not inseret </span>";
                    return $msg;
              }   
       }

       
       public function getBima($id){
         $query ="SELECT sum(monthlyAday), COUNT(*) FROM `tbl_bima_aday` WHERE customerId =$id "; 
         $result = $this->db->select($query);
         return $result;  
       }
       
       
       public function getBimacounter($id){
         $query ="SELECT * FROM tbl_bima_aday WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;     
       }
       
        public function getsthayisonchoykisti($id){
         $query ="SELECT * FROM btl_sthayi_sonchoy_aday WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;     
       }
       
       
        public function getgeneralSonchoyaday($id){
         $query ="SELECT sum(gnsonchoyaday), COUNT(*) FROM `tbl_general_sonchoy_aday`  WHERE customerId ='$id'"; 
         $result = $this->db->select($query);
         return $result;  
       }
       
  
       public function getDate($id){
         $query ="SELECT date FROM `tbl_general_sonchoy_aday`  WHERE customerId ='$id' ORDER BY date ASC LIMIT 1"; 
         $result = $this->db->select($query);
         return $result;  
       }
       
       
       public function pgetDate($id){
         $query ="SELECT date FROM `btl_sthayi_sonchoy_aday`  WHERE customerId ='$id' ORDER BY date ASC LIMIT 1"; 
         $result = $this->db->select($query);
         return $result;  
       }
       
       public function getgnprofit($id){
         $query ="SELECT * FROM `tbl_general_saving_profit`  WHERE customerId ='$id'"; 
         $result = $this->db->select($query);
         return $result;    
       }

       



       public function profitinsert($id,$interest){
       $query = "INSERT INTO tbl_general_saving_profit
                     (customerId, profit)
                      VALUES
                     ('$id','$interest')";
            
                    $inserted_row = $this->db->insert($query);
                    if ($inserted_row) {
                    $msg = "<span style='color:#ffff'>Insert  successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'>Not inseret </span>";
                    return $msg;
              }    
       }
      
       public function profitupdate($id, $interest){
         $query ="UPDATE tbl_general_saving_profit
                    SET
                    
                    profit                 = '$interest'                     
                    WHERE customerId       = '$id'"; 

   
              $updeted_row = $this->db->update($query);
              if ($updeted_row) {
               $msg = "<span style='color:#ffff;'> updated successfully.</span>";
               return $msg;
                   }else{
                    $msg = "<span style='color:red'>not updated </span>";
                    return $msg;
              }    
       }
       
       
       
       public function psrofitupdate($id, $psprofit){
          $query ="UPDATE tbl_psaving_profit
                    SET
                    
                    psprofit                 = '$psprofit'                     
                    WHERE customerId       = '$id'"; 

   
              $updeted_row = $this->db->update($query);
              if ($updeted_row) {
               $msg = "<span style='color:#000;'> updated successfully.</span>";
               return $msg;
                   }else{
                    $msg = "<span style='color:red'>not updated </span>";
                    return $msg;
              }   
       }

       

       public function getallprofit($id){
        $query ="SELECT sum(profit), COUNT(*) FROM `tbl_general_saving_profit` WHERE customerId ='$id'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function getliftprofit($id){
        $query ="SELECT sum(gnprofit), COUNT(*) FROM `tbl_general_sonchoy_uttolon` WHERE customerId ='$id'"; 
         $result = $this->db->select($query);
         return $result;      
       }

       

       public function getGNsonchoykisti($id){
         $query ="SELECT * FROM tbl_general_sonchoy_aday WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;   
       }
       
       public function getgnUttolon($id){
         $query ="SELECT sum(gnuttolon), COUNT(*) FROM `tbl_general_sonchoy_uttolon` WHERE customerId ='$id'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
        public function getSTHsonchoy($id){
         $query ="SELECT sum(sthuttolon), COUNT(*) FROM `tbl_sthayil_sonchoy_uttolon` WHERE customerId ='$id'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       
         public function getBimaUttolon($id){
         $query ="SELECT sum(bimaUttolon), COUNT(*) FROM `tbl_bima_uttolon` WHERE customerId ='$id'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       
       public function gettotalamunt(){
        $query ="SELECT * FROM tbl_loan WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function stutas($id){
         $query ="SELECT cuslevel FROM tbl_customer WHERE customerId='$id'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function activeCustomerr($activeCustomerid){
         $query ="UPDATE tbl_customer a 
                 LEFT JOIN tbl_loan b ON a.customerId = b.customerId 
                 LEFT JOIN tbl_kisti_aday c ON c.customerId = b.customerId SET a.cuslevel= '0', b.loanstutas= '0', c.kistiStutas = '0' WHERE a.customerId = '$activeCustomerid'"; 
         $updated_row = $this->db->update($query);                            
 
       } 
       
        public function finishbyid($finish){
         $query ="UPDATE tbl_customer a LEFT JOIN tbl_loan b ON a.customerId = b.customerId LEFT JOIN tbl_kisti_aday c ON c.customerId = b.customerId SET a.cuslevel= '1', b.loanstutas= '1', c.kistiStutas = '1' WHERE a.customerId = '$finish'"; 
         $updated_row = $this->db->update($query);                            
 
       }
       
       public function getTotal(){
        $query ="SELECT sum(amount), COUNT(*) FROM `tbl_loan` WHERE loanstutas='0'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function getTotalAday(){
         $query ="SELECT sum(kistiaday), COUNT(*) FROM `tbl_kisti_aday` WHERE kistiStutas='0'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function getProfit(){
        $query ="SELECT sum(munafa), COUNT(*) FROM `tbl_loan` WHERE loanstutas='0'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function deletecustomer($deleteid){
            
        $query ="delete cus.*, loan.*, stayisonchoyaday.*, generalsonchoyaday.*, gnsonchoyuttolon.*, kisti.*, nomoni.*, sthsonchoyuttlon.*, stayisonchoy.*,
            bima.*, bima_aday.*, bima_uttolon.*, totalprofit.*, psprofit.*, gsavingprofit.* 
            from tbl_customer as cus 
            left join tbl_loan as loan on loan.customerId = cus.customerId 
            left join tbl_nomoni as nomoni on nomoni.customerId = cus.customerId 
            left join tbl_kisti_aday as kisti on kisti.customerId = cus.customerId 
            left join btl_sthayi_sonchoy_aday as stayisonchoyaday on stayisonchoyaday.customerId = cus.customerId 
            left join tb_sthayi_sonchoy as stayisonchoy on stayisonchoy.customerId = cus.customerId 
            left join tbl_general_sonchoy_aday as generalsonchoyaday on generalsonchoyaday.customerId = cus.customerId 
            left join tbl_general_sonchoy_uttolon as gnsonchoyuttolon on gnsonchoyuttolon.customerId = cus.customerId 
            left join tbl_sthayil_sonchoy_uttolon as sthsonchoyuttlon on sthsonchoyuttlon.customerId = cus.customerId
            
            left join tbl_bima as bima on bima.customerId = cus.customerId 
            left join tbl_bima_aday as bima_aday on bima_aday.customerId = cus.customerId 
            left join tbl_bima_uttolon as bima_uttolon on bima_uttolon.customerId = cus.customerId 
            
            left join tbl_dps_totalprofit as totalprofit on totalprofit.customerId = cus.customerId
            left join tbl_psaving_profit as psprofit on psprofit.customerId = cus.customerId
            left join tbl_general_saving_profit as gsavingprofit on gsavingprofit.customerId = cus.customerId
            
            where cus.customerId = '$deleteid'";    
           $result = $this->db->delete($query);
           return $result;   
       }
       
       public function getGNsonchoy(){
        $query ="SELECT sum(gnsonchoyaday), COUNT(*) FROM `tbl_general_sonchoy_aday`"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function getGNsonchoyUttolon(){
         $query ="SELECT sum(gnuttolon), COUNT(*) FROM `tbl_general_sonchoy_uttolon`"; 
         $result = $this->db->select($query);
         return $result;   
       }
       
       public function getSthayisonchoyy(){
         $query ="SELECT sum(sthayiaday), COUNT(*) FROM `btl_sthayi_sonchoy_aday`"; 
         $result = $this->db->select($query);
         return $result;   
       }
       
       public function getSthayisonchoyUttolon(){
        $query ="SELECT sum(sthuttolon), COUNT(*) FROM `tbl_sthayil_sonchoy_uttolon`"; 
         $result = $this->db->select($query);
         return $result;     
       }
       
       
        public function getBimaAll(){
        $query ="SELECT sum(monthlyAday), COUNT(*) FROM `tbl_bima_aday`"; 
         $result = $this->db->select($query);
         return $result;     
       }
       
       
        public function getBimaUttolonAll(){
        $query ="SELECT sum(bimaUttolon), COUNT(*) FROM `tbl_bima_uttolon`"; 
         $result = $this->db->select($query);
         return $result;     
       }
       
       
       
       public function getDailyCustomer(){
         $query ="SELECT loanType FROM `tbl_loan` WHERE loanType = 'DailySortTime' AND loanstutas='0'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function getDailyLongTimeCus(){
        $query ="SELECT * FROM `tbl_loan` WHERE loanType ='DailyLongTime' AND loanstutas='0'"; 
         $result = $this->db->select($query);
         return $result;    
       }

              public function getweeklyCustomer(){
        $query ="SELECT loanType FROM `tbl_loan` WHERE loanType ='Weekly' AND loanstutas = '0'"; 
         $result = $this->db->select($query);
         return $result;    
       }
       
       public function getMontlyCustomer(){
        $query ="SELECT loanType FROM `tbl_loan` WHERE loanType ='Monthly' AND loanstutas = '0'"; 
        $result = $this->db->select($query);
        return $result;     
       }
       
       public function getTotalCustomer(){
        $query ="SELECT loanType FROM `tbl_loan` WHERE loanstutas = '0'"; 
        $result = $this->db->select($query);
        return $result;    
       }
       
        public function getTotalBimaCustomer(){
        $query ="SELECT customerId FROM `tbl_bima`"; 
        $result = $this->db->select($query);
        return $result;    
       }
       
        public function generaleSavingCustomer(){
        $query ="SELECT customerId FROM `tbl_customer`"; 
        $result = $this->db->select($query);
        return $result;    
       }
       
        public function permentSavingCustomer(){
        $query ="SELECT customerId FROM `tb_sthayi_sonchoy`"; 
        $result = $this->db->select($query);
        return $result;    
       }
       
       
       public function getAllkisti($id){
        $query ="SELECT * FROM `tbl_kisti_aday` WHERE  customerId ='$id'"; 
        $result = $this->db->select($query);
        return $result;    
       }
       
       public function gnsonchoy($id){
        $query ="SELECT * FROM `tbl_general_sonchoy_aday` WHERE  customerId ='$id'"; 
        $result = $this->db->select($query);
        return $result;     
       }
       
       public function sthsonchoy($id){
        $query ="SELECT * FROM `btl_sthayi_sonchoy_aday` WHERE  customerId ='$id'"; 
        $result = $this->db->select($query);
        return $result;    
       }
       
       public function bimaList($id){
        $query ="SELECT * FROM `tbl_bima_aday` WHERE  customerId ='$id'"; 
        $result = $this->db->select($query);
        return $result;    
       }
       
       
       public function sthsonchoyUttolon($id){
        $query ="SELECT * FROM `tbl_sthayil_sonchoy_uttolon` WHERE  customerId ='$id'"; 
        $result = $this->db->select($query);
        return $result;   
       }
       
       public function bimaUttolonList($id){
        $query ="SELECT * FROM `tbl_bima_uttolon` WHERE  customerId ='$id'"; 
        $result = $this->db->select($query);
        return $result;   
       }
       
       public function gnsonchoyUttolon($id){
        $query ="SELECT * FROM `tbl_general_sonchoy_uttolon` WHERE  customerId ='$id'"; 
        $result = $this->db->select($query);
        return $result;    
       }
       
       public function printcustomer($id){

   $query ="SELECT tbl_customer.*, tbl_loan.*, tb_sthayi_sonchoy.*
            FROM tbl_customer
            LEFT JOIN tbl_loan ON tbl_customer.customerId = tbl_loan.customerId
            LEFT JOIN tb_sthayi_sonchoy ON tbl_customer.customerId = tb_sthayi_sonchoy.customerId
            WHERE tbl_customer.customerId ='$id'"; 
        $result = $this->db->select($query);
        return $result;  
       }
       
       
       public function getrinbima(){
        $query ="SELECT sum(rinBima), COUNT(*) FROM tbl_rinbima"; 
         $result = $this->db->select($query);
         return $result;     
       }
       
      public function getdpsonemonth(){
      $query ="SELECT sum(bimaAday), COUNT(*) FROM tbl_bima"; 
         $result = $this->db->select($query);
         return $result;    
     }
     
     public function getDpsProfit($id){
     $query ="SELECT * FROM tbl_dps_totalprofit WHERE customerId='$id'"; 
     $result = $this->db->select($query);
     return $result;     
     }
     
     public function dpsprofitinsert($id, $interestt){

         $query ="INSERT INTO tbl_dps_totalprofit(customerId, profit) VALUE('$id', '$interestt')";
         $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'> Insert successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'> Not insert.</span>";
             return $msg;
         }   
     }
     
     public function dpsProfitUpdate($id, $interest){
         $query ="UPDATE tbl_dps_totalprofit
                    SET
                    profit   = '$interest'
                 
                     WHERE customerId = '$id'"; 

   
              $updeted_row = $this->db->update($query);
              if ($updeted_row) {
               $msg = "<span style='color:#0000;'>  Updated Successfully.</span>";
               return $msg;
             
            }else {
             $msg = "<span style='color:#0000;'>  Not Updated !</span>";
             return $msg;
            }   
     }
     
     public function getDpsProfitLift($id){
      $query ="SELECT sum(profit_lift), COUNT(*) FROM tbl_bima_uttolon WHERE customerId='$id'"; 
      $result = $this->db->select($query);
      return $result;    
     }
       
      
         
         
 
}      