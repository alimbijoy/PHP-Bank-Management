<?php
 $filepath = realpath(dirname(__FILE__));
 include_once($filepath.'/../lib/Database.php');
 include_once($filepath.'/../helpers/Format.php');
 	
  ?>

<?php

class Search{
	
	private $db;
	private $fm;

	function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
	} 
        
        public function search($data){  
           $searchbyname = $this->fm->validation($data['search']);  
            $customerName = $this->fm->validation($data['name']); 
           if($searchbyname){
            $query = "SELECT tbl_customer.*, tbl_loan.loanType 
                FROM tbl_customer 
                      LEFT JOIN tbl_loan 
                      ON tbl_customer.customerId = tbl_loan.customerId
                     WHERE tbl_customer.customerId LIKE '%" . $searchbyname . "%' LIMIT 1"; 
            $result = $this->db->select($query);     
            return $result;     
           } else {
            $query = "SELECT tbl_customer.*, tbl_loan.loanType 
                FROM tbl_customer 
                      LEFT JOIN tbl_loan 
                      ON tbl_customer.customerId = tbl_loan.customerId
                     WHERE tbl_customer.CustomerName LIKE '%" . $customerName . "%' LIMIT 1";  
            $result = $this->db->select($query);
            return $result; 
      
       }

   }
   
   
 

   

   public function addkisti($data, $id, $type){
    $kisti = $this->fm->validation($data['kistiaday']);
    
   if(empty($kisti)){
     $msg = "<span style='color:#FA2433;'>Fild Must Not be empty!</span>";
      return $msg;  
   } else {

      $query = "INSERT INTO tbl_kisti_aday (customerId, kistiaday, loanType) VALUES ('$id', '$kisti', '$type')";

          $inserted_row = $this->db->insert($query);
          if ($inserted_row) {
           $msg = "<span style='color:#45B52E;'>Kisti inserted Successfully</span>";
           return $msg;
          }else{
           $msg = "<span style='color:FA2433'> kisti not inserted Successfully</span>";
           return $msg;
     }
   
   }
 }
 
 public function addGnsonshoy($data, $id){
   $gnsonchoyaday = $this->fm->validation($data['gnsonchoyaday']);
      if(empty($gnsonchoyaday)){
     $msg = "<span style='color:#FA2433;'>Fild Must Not be empty!</span>";
      return $msg;  
        } else {

           $query = "INSERT INTO tbl_general_sonchoy_aday (customerId, gnsonchoyaday) VALUES ('$id', '$gnsonchoyaday')";

               $inserted_row = $this->db->insert($query);
               if ($inserted_row) {
                $msg = "<span style='color:#45B52E;'>General Sonchoy inserted Successfully</span>";
                return $msg;
               }else{
                $msg = "<span style='color:FA2433'> General Sonchoy  not inserted Successfully</span>";
                return $msg;
          }

        } 
     
     
 }
 
 public function addSthayisonshoy($data, $id){
     
    
      $sthayiaday = $this->fm->validation($data['sthayiaday']);
      if(empty($sthayiaday)){
     $msg = "<span style='color:#FA2433;'>Fild Must Not be empty!</span>";
      return $msg;  
        } else {

           $query = "INSERT INTO btl_sthayi_sonchoy_aday (customerId, sthayiaday) VALUES ('$id', '$sthayiaday')";

               $inserted_row = $this->db->insert($query);
               if ($inserted_row) {
                $msg = "<span style='color:#45B52E;'>General Sonchoy inserted Successfully</span>";
                return $msg;
               }else{
                $msg = "<span style='color:FA2433'> General Sonchoy  not inserted Successfully</span>";
                return $msg;
          }

        } 
  
 }
 
 
 
  public function addmonthlyBima($data, $id){
     
    
      $monthlyAday = $this->fm->validation($data['monthlyAday']);
      if(empty($monthlyAday)){
     $msg = "<span style='color:#FA2433;'>Fild Must Not be empty!</span>";
      return $msg;  
        } else {

           $query = "INSERT INTO tbl_bima_aday (customerId, monthlyAday) VALUES ('$id', '$monthlyAday')";

               $inserted_row = $this->db->insert($query);
               if ($inserted_row) {
                $msg = "<span style='color:#45B52E;'>Bima inserted Successfully</span>";
                return $msg;
               }else{
                $msg = "<span style='color:FA2433'> Bima  not inserted Successfully</span>";
                return $msg;
          }

        } 
  
 }
 
 
 
 

      
      
        
}

?>