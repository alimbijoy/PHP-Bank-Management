
<?php
 $filepath = realpath(dirname(__FILE__));
 include_once($filepath.'/../lib/Database.php');
 include_once($filepath.'/../helpers/Format.php');
 	
  ?>

<?php

class FrontEnd{
	
	private $db;
	private $fm;

	function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
	} 
        
        public function addSlider($data, $file){
              
        $title             = $data['title'];
        $description       = $data['description'];

        $permited  = array('jpg', 'jpeg', 'png', 'gif');
        $file_name = $file['image']['name'];
        $file_size = $file['image']['size'];
        $file_temp = $file['image']['tmp_name'];
        
       
        
        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image_name = substr(md5(time()), 0, 10).'.'.$file_ext;
        $uploaded_image = "upload/".$unique_image_name;
        
         if(empty($title)|| empty($description)){			    	
          $msg = "<span style=color:red;>Field must not empty!</span>";
          return $msg;    
         }elseif(empty($file_name)) {
         $msg = "<span class='error'>Please select a image</span>";
         return $msg;
          }elseif ($file_size >1048567) {
              $msg = "<span class='error'>Image size should be less then 1 mb!</span>";
              return $msg;
          }elseif (in_array($file_ext, $permited) === false) {
              $msg = "<span class='error'>you can upload only:-".implode(', ', $permited)."</span>";
              return $msg;

        }else {          
              move_uploaded_file($file_temp, $uploaded_image);       
            $query = "INSERT INTO fornt_slider(title, description, image) VALUES('$title', '$description', '$uploaded_image')";
            $inserted_row = $this->db->insert($query);
            if ($inserted_row) {
                    $msg = "<span style='color:green'>Slider inserted Successfully</span>";
                    return $msg;
            }else{
                    $msg = "<span style='color:red'>Slider not inserted Successfully</span>";
                    return $msg;
              }
              
        } 
    
     }
  public function getSlider(){
    $query = "SELECT * FROM fornt_slider";
    $result = $this->db->select($query);     
    return $result;         
 }    
 
 
 
  public function addtitle($data){
   $title  = $this->fm->validation($data['title']);
   $ftitle  = $this->fm->validation($data['ftitle']);

   if(empty($title) || empty($ftitle)){
     $msg = "<span style='color:#ffff;'> Field mus not be empty!</span>";
     return $msg; 
   }else{
    $query ="INSERT INTO tbl_title (title, ftitle) VALUE('$title','$ftitle')";
    
     $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'> Add successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'>  Not Add successfully.</span>";
             return $msg;
         }
       }    
     }
     
     public function addtitlelist(){
      
      $query = "SELECT * FROM  tbl_title ";     
      $result = $this->db->select($query);
      return $result;    
     }
     
     public function deltitl($id){
     $query = "DELETE FROM tbl_title WHERE id = '$id'";
      $result = $this->db->delete($query);
      return $result;    
     }

 
}




?>


