<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['customerId'])){
    $customerId = $_GET['customerId'];

}

?>


<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $addNomoni = $customer->addNomoni($_POST, $_FILES, $customerId);
    }

 ?>

                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Add Nomoni:</h2>
           <?php 
            if(isset($addNomoni)){
                echo $addNomoni;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data" style="background-color: #2D89EF">
						  <fieldset>
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div> 
                                                      
                                                      
                                                      
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">Name </label>
							  <div class="controls">
                                                              <input type="text" name="nomoniName" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                       </div>
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">Father Name</label>
							  <div class="controls">
                                                              <input type="text" name="fatherName" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Mother Name</label>
							  <div class="controls">
                                                              <input type="text" name="motherName" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                          

							<div class="control-group">
							  <label class="control-label" for="typeahead">village </label>
							  <div class="controls">
                                                              <input type="text" name="village" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                      <div class="control-group">
							  <label class="control-label" for="typeahead">Age of Nomoni </label>
							  <div class="controls">
                                                              <input type="text" name="age" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                      <div class="control-group">
							  <label class="control-label" for="typeahead">Relation Of Nomoni </label>
							  <div class="controls">
                                                              <input type="text" name="nomorelation" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>


                                                        <div class="control-group">
                                                            <label class="control-label" for="fileInput">photo (PP Size)</label>
                                                            <div class="controls">
                                                                <input name="image" class="input-file uniform_on" id="fileInput" type="file">
                                                            </div>
							</div>
							


							

							          
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Add Nomoni</button>
							     
							</div>
                                                       
						  </fieldset>
						</form>   

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>