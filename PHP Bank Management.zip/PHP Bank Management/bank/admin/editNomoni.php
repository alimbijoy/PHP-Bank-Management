<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['customerId'])){
    $customerId = $_GET['customerId'];

}

?>


<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $updateNomoni = $customer->updateNomoni($_POST, $_FILES, $customerId);
    }

 ?>

                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Edit Nomoni:</h2>
           <?php 
            if(isset($updateNomoni)){
                echo $updateNomoni;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data" style="background-color: #2D89EF">
						  <fieldset>
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div> 
                                                      <?php
                                                       $getNomoniById = $customer->getNomoniById($customerId);
                                                       if($getNomoniById){
                                                           while ($result = $getNomoniById->fetch_assoc()){
                                                               
                                                       
                                                      ?>
                                                      
                                                      
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">Name </label>
							  <div class="controls">
                                                              <input type="text" name="nomoniName" value="<?php echo $result['nomoniName']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                       </div>
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">Father Name</label>
							  <div class="controls">
                                                              <input type="text" name="fatherName" value="<?php echo $result['fatherName']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Mother Name</label>
							  <div class="controls">
                                                              <input type="text" name="motherName" value="<?php echo $result['motherName']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                          

							<div class="control-group">
							  <label class="control-label" for="typeahead">village </label>
							  <div class="controls">
                                                              <input type="text" name="village" value="<?php echo $result['village']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                      <div class="control-group">
							  <label class="control-label" for="typeahead">Age of Nomoni </label>
							  <div class="controls">
                                                              <input type="text" name="age" value="<?php echo $result['age']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                      <div class="control-group">
							  <label class="control-label" for="typeahead">Relation Of Nomoni </label>
							  <div class="controls">
                                                              <input type="text" name="nomorelation" value="<?php echo $result['nomorelation']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>


                                                        <div class="control-group">
                                                            <label class="control-label" for="fileInput">photo (PP Size)</label>
                                                            <div class="controls">
                                                            
                                                                <input type="file" name="image" class="input-file uniform_on" id="fileInput" >
                                                            </div>
							</div>
							


                                                       <?php } } ?>

							          
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Update Nomoni</button>
							  <button type="reset" class="btn">Cancel</button>
							</div>
						  </fieldset>
						</form>   

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>