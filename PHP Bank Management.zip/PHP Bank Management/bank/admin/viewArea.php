<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['areaId'])||$_GET['areaId']==NULL){
    
    $id = $_GET['areaId'];
}
?>



<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $editArea = $customer->editArea($_POST, $id);
    }

 ?>

                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Edit Area:</h2>
           <?php 
            if(isset($editArea)){
                echo $editArea;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST" enctype="" style="background-color: #2D89EF">
						  <fieldset>
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div> 
                                                      
                                                      <?php 
                                                      $getArea = $customer->getArea($id);
                                                      if($getArea){
                                                          while ($result = $getArea->fetch_assoc()){
                                                              
                                                      
                                                      ?>
                                                      
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">Area Name </label>
							  <div class="controls">
                                                              <input type="text" name="areaName" value="<?php echo $result['areaName']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                       </div>
                                                      
						
                                                      <?php } } ?>    
                         
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Update Area</button>
							  <button type="reset" class="btn">Cancel</button>
							</div>
						  </fieldset>
						</form>   

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>