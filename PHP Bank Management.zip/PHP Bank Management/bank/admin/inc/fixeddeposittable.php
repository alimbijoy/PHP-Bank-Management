    
<?php 
 $fixed_deposit_customer = $fixedDeposit->fixed_deposit_customer();
      if($fixed_deposit_customer){
                                         
        $fixed_deposit_cus = mysqli_num_rows($fixed_deposit_customer);
        Session::set('fixeddepositcus', $fixed_deposit_cus);
      }

?>


<?php 
$totalfixed_deposit_amount = $fixedDeposit->totalfixed_deposit_amount();
if($totalfixed_deposit_amount){
    while ($row = $totalfixed_deposit_amount->fetch_assoc()){
        $totalfixed_deposit= $row['sum(amount)'];
         $divfix       = $totalfixed_deposit/1000;
         $fixpersent   = $divfix * 1.5; 
        Session::set('fixpersent', $fixpersent);  
        Session::set('totalfixed_deposit', $totalfixed_deposit);  
 
    }
}


?>

<?php 
$totalfixed_deposit_profitt = $fixedDeposit->totalfixed_deposit_profit();
if($totalfixed_deposit_profitt){
    while ($row = $totalfixed_deposit_profitt->fetch_assoc()){
        $totalfixed_deposit_profit= $row['sum(Profit_amount)'];
        Session::set('totalfixed_deposit_profit', $totalfixed_deposit_profit);  
 
    }
}


?>


<?php
$getfixeddeposittotalprofit = $fixedDeposit->getfixeddeposittotalprofit();
if($getfixeddeposittotalprofit){
    while ($row = $getfixeddeposittotalprofit->fetch_assoc()){
        $result = $row['sum(dps_profit)'];
        
        $profitremaining = $result-Session::get("totalfixed_deposit_profit");
    }
}
?>




<table border="2" class="table1" style="width:100%; margin: 5px;">
     
        <tr>

              <td colspan="6" style="text-align: center;  background: #FF9800">Fixed deposit  Customers  Information</td>

        </tr>

        <tr>
          <td width="16.66%">Fixed deposit customer</td>
          <td width="16.66%"><?php echo Session::get("fixeddepositcus"); ?></td>
          <td width="16.66%">Total fixed deposit amount</td>
          <td width="16.66%"><?php echo Session::get("totalfixed_deposit"); ?> </td>
          <td width="16.66%">Total fixed deposit lift profit </td>
          <td width="16.66%"><?php echo Session::get("totalfixed_deposit_profit"); ?></td>
        
        </tr>
         <tr>
          <td width="16.66%">Fixed deposit total profit</td>
          <td width="16.66%"><?php echo $result; ?></td>
          <td width="16.66%">Fixed deposit profit lift</td>
          <td width="16.66%"><?php echo Session::get("totalfixed_deposit_profit"); ?> </td>
          <td width="16.66%">Profit remaining  </td>
          <td width="16.66%"><?php echo $profitremaining; ?></td>
        
        </tr>
                                                
                                                
    </table> 