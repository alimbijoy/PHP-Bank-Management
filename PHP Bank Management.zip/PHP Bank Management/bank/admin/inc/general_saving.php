                                                 <tr>
                                                  
                                                     <td style="text-align: center;  background: #DB0D15" colspan="3">General saving</td>
                                                  
                                                </tr>
                                               
                                                
                                              <?php 
                                               $getgeneralSonchoyaday = $loan->getgeneralSonchoyaday($id);
                                               if($getgeneralSonchoyaday){
                                                   while ($row = $getgeneralSonchoyaday->fetch_assoc()){
                                                     $sum  = $row['sum(gnsonchoyaday)'];
                                                      $gnuttolon = Session::get("gnuttolon");
                                                      $result = $sum - $gnuttolon;  
                                               ?> 
                                                
                                                <tr>
                                                  <td>Current Balance and profit</td>
                                                  
                                                  <td colspan="2"><?php echo $result; ?> Taka ||
                                                      <?php 
                                                        $getDate = $loan->getDate($id);
                                                        if($getDate){
                                                         while($row = $getDate->fetch_assoc()){
                                                        $date = $row['date'];
                                                        }}
                                                      if(isset($date)){
                                                       $month = $dateMonth->monthcount($date);                                          
                                                       $r    = 0.06; 
                                                       $interest = $dateMonth->simpleinterset($result, $month, $r);
                                                      
                                                       $datee  = date("2018-01-01");
                                                       $m = $dateMonth->monthcal($datee);
                                                       $d = $dateMonth->datecal($datee);
                                                       $year = 330;
                                                       
                                                       $getgnprofit = $loan->getgnprofit($id);
                                                       if($year==330 AND empty($getgnprofit)){
                                                         $profitinsert = $loan->profitinsert($id, $interest);
                                                         
                                                       } elseif($year==335 ||$year==330 ||$year==325 || $year==320) {
                                                        $profitupdate = $loan->profitupdate($id, $interest); 
                                                      
                                                       }
                                                     
                                                   }    
                                                       
                                                       
                                                      $getallprofit = $loan->getallprofit($id);
                                                      if($getallprofit){
                                                          while ($row=$getallprofit->fetch_assoc()){
                                                              $profit = $row['sum(profit)'];
                                                             
                                                          }    
                                                      }
                                                      
                                                     $getliftprofit = $loan->getliftprofit($id); 
                                                      if($getliftprofit){
                                                          while ($row=$getliftprofit->fetch_assoc()){
                                                             $liftprofit = $row['sum(gnprofit)']; 
                                                          }    
                                                      }
                                                      
                                                      echo $profit-$liftprofit;
                                                        ?> 
                                                  </td>
                                                  
                                                </tr>
                                                
                                               <tr>
                                                  <td>Total lifted</td>
                                                  <td colspan="2"><?php echo $gnuttolon; ?> Taka // <a style="color:#DB0D15;" href="gnuttolon.php?customerId=<?php echo Session::get("customerId"); ?>"> More</a></td>
                                                  
                                                </tr>
                                                <tr>
                                                  <td>Intotal with lifted</td>
                                                  <td colspan="2"><?php echo $sum; ?> Taka</td>
                                                  
                                                </tr>
                                                
                                               
                                                
                                               <?php } } ?>
                                                <?php 
                                                $getgnUttolon = $loan->getgnUttolon($id);
                                               if($getgnUttolon){
                                                   while ($row = $getgnUttolon->fetch_assoc()){
                                                     $result  = $row['sum(gnuttolon)']; 
                                                 Session::set('gnuttolon', $result);
                                                 } 
                                               
                                              }
                                                ?>
       
                                               <?php 
                                                 $getGNsonchoykisti = $loan->getGNsonchoykisti($id);
                                                    
                                                   if($getGNsonchoykisti){
                                                     
                                                   $count = mysqli_num_rows($getGNsonchoykisti);

                                                ?>  
                                                  
                                                
                                                
                                                <tr>
                                                  <td>Number of payment</td>
                                                  <td colspan="2"><?php echo $count; ?>  // <a style="color:#DB0D15;" href="gnsonchoy.php?customerId=<?php echo Session::get("customerId"); ?>"> More</a></td>
                                                  
                                                </tr>

                                              
                                              <?php }  ?>        
                                                