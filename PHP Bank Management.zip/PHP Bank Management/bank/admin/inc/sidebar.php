<div class="container-fluid-full">
		<div class="row-fluid">
				
			<!-- start: Main Menu -->
			<div id="sidebar-left" class="span2">
				<div class="nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
                                                
                                              <a href=""><span style="background: #E21E27; display: block; padding: 5px; color: #fff;text-align: center; "> Admin Panel</span></a>
						
						<li>
                                                    <a href="index.php"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a>
						</li>
                                                
						<a href=""><span style="background: #E21E27; display: block; padding: 5px; color: #fff;text-align: center; "> Customer</span></a>			
						<li>
							<a href="add_customer.php"><i class="icon-folder-close-alt"></i>Add Customer</a>	
						</li>
                                                <li>
							<a href="customer_list.php"><i class="icon-folder-close-alt"></i>Customer List</a>	
						</li>
                                                
                                         
                                                
                                              
                                                
                                                <?php 
                                                 
                                           
                                                      
                                                        if(Session::get("adminRole") == '1') { ?>
                                                          <a href=""><span style="background: #E21E27; display: block; padding: 5px; color: #fff;text-align: center; "> User</span></a>
                                                            <li>
                                                                   <a href="add_user.php"><i class="icon-folder-close-alt"></i>Add User</a>	
                                                           </li>

                                                            <li>
                                                                   <a href="userList.php"><i class="icon-folder-close-alt"></i>User List</a>	
                                                           </li>  
                                                           
                                                            <a href=""><span style="background: #E21E27; display: block; padding: 5px; color: #fff;text-align: center; "> Fixed deposit</span></a>			
                                                            <li>
                                                                    <a href="fixed_deposit.php"><i class="icon-folder-close-alt"></i>Add fixed deposit</a>	
                                                            </li>
                                                            <li>
                                                                    <a href="fixed_deposit_list.php"><i class="icon-folder-close-alt"></i>fixed deposit list</a>	
                                                            </li>

                                                
                                                       
                                                    <?php } ?>
                                                
                                              
                                                  
                                                    
                                                
                                                
                                                     
                                                
						
                                               
                                                
                                                 <a href=""><span style="background: #E21E27; display: block; padding: 5px; color: #fff;text-align: center; "> Area</span></a>
                                                
                                                <li>
							<a href="addArea.php"><i class="icon-folder-close-alt"></i>Add Area</a>	
						</li>
                                                <li>
							<a href="areaList.php"><i class="icon-folder-close-alt"></i>Area List</a>	
						</li>
                                                
                                                
                                              
                                                
                                                
                                                <a href=""><span style="background: #E21E27; display: block; padding: 5px; color: #fff;text-align: center; "> Sheet</span></a>
                                                
                                                <li>
							<a href="sheetDaily.php"><i class="icon-folder-close-alt"></i>Payment sheet</a>	
						</li>
                                                
                                                <a href=""><span style="background: #E21E27; display: block; padding: 5px; color: #fff;text-align: center; "> Title</span></a>
                                                
                                                <li>
							<a href="add_tile.php"><i class="icon-folder-close-alt"></i>Add title</a>
                                                        
						</li>
                                                
                                                <li>
                                                    <a href="title_list.php"><i class="icon-folder-close-alt"></i>Title list</a>
                                                </li>
                                                
                                               <a href=""><span style="background: #E21E27; display: block; padding: 5px; color: #fff;text-align: center; "> Frond End</span></a>
                                            <li>
                                                    <a href="fron_Slidar_add.php"><i class="icon-folder-close-alt"></i>Add Slider</a>	
                                            </li>
                                            <li>
                                                    <a href="fron_Slidar_list.php"><i class="icon-folder-close-alt"></i>Slider list</a>	
                                            </li>
                                            
					</ul>
				</div>
			</div>
			<!-- end: Main Menu -->
			
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>