<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['customerId'])){
    $id = $_GET['customerId'];
   
    
}

?>
          
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Kisti List:</h2>
         
		<div class="row-fluid">
			
					<div class="box-content">
                                           
                                          
                                            
                                           <table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Kisti Amount</th>
								  <th>Date</th>
								  
							  </tr>
						  </thead> 
                                                  
                                           <?php
                                             $getAllkisti = $loan->getAllkisti($id);
                                             if($getAllkisti ){
                                                 while($result = $getAllkisti->fetch_assoc()){
                                        
                                            ?>   
                                                  
                                                  
						  <tbody>
							<tr>
                                                            <td><?php echo $result['kistiaday']; ?></td>
						            <td class="center"><?php echo $fm->formatDate($result['date']); ?></td>
					
							</tr>
							
						  </tbody>
                                                  
                                             <?php } } ?>       
                                                  
					  </table>
                                            

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>