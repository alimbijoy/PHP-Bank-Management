<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $addcustomer = $customer->addCustomer($_POST, $_FILES);
    }

 ?>

                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Add Customer:</h2>
           <?php 
            if(isset($addcustomer)){
                echo $addcustomer;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data" style="background-color: #2D89EF" >
						  <fieldset>
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div>  
                                                      
                                                    <div class="control-group">
                                                      <label class="control-label" for="selectError3">Customer Vallage or Area</label>
                                                      <div class="controls">

                                                          <select name="customerArea" id="selectError3">
                                                              <option>Select</option>
                                                         <?php
                                                          $getAllArea = $customer->getAllArea();
                                                              if($getAllArea){
                                                                  while ($result = $getAllArea->fetch_assoc()){

                                                          ?>
                                                              <option value="<?php echo $result['areaName']; ?>"><?php echo $result['areaName']; ?></option>
                                                           <?php } } ?>       

                                                        </select>
                                                             
                                                          
                                                      </div>
                                                   </div> 
                                                      
                                                      
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">Name</label>
							  <div class="controls">
                                                              <input type="text" name="CustomerName" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                        </div> 

							<div class="control-group">
							  <label class="control-label" for="typeahead">Father's Name</label>
							  <div class="controls">
                                                              <input type="text" name="cusfatherName" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Mother's Name</label>
							  <div class="controls">
                                                              <input type="text" name="cusmotherName" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Village</label>
							  <div class="controls">
                                                              <input type="text" name="cusvillage" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Post</label>
							  <div class="controls">
                                                              <input type="text" name="cuspost" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Thana</label>
							  <div class="controls">
                                                              <input type="text" name="custhana" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                        <div class="control-group">
							  <label class="control-label" for="typeahead">District</label>
							  <div class="controls">
                                                              <input type="text" name="cusDistrict" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                    <div class="control-group">
                                                      <label class="control-label" for="selectError3">Gender</label>
                                                      <div class="controls">
                                                          <select name="cusgender" id="selectError3">
                                                              <option>Select</option>
                                                              <option value="Male">Male</option>
                                                              <option value="Female">Female</option>
                                                              

                                                        </select>
                                                      </div>
                                                   </div> 
                                                      
                                                      
                                                       <div class="control-group">
							  <label class="control-label" for="typeahead">Nid or Birth Reg</label>
							  <div class="controls">
                                                              <input type="text" name="cusnid" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Mobile Number</label>
							  <div class="controls">
                                                              <input type="text" name="cusmobileNumber" class="span4 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         
                                                        <div class="control-group">
							  <label class="control-label" for="typeahead">Joining Date</label>
							  <div class="controls">
                                                              <input type="text" name="cusJoinDate" class="span4 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                      
                                                       <div class="control-group">
							  <label class="control-label">Date of Birth</label>
							  <div class="controls">
                                                              <input type="text" name="cusdateOfBirth">
							  </div>
							</div> 
                                                      
                                                      
                                    
                                                          

                                                        <div class="control-group">
                                                            <label class="control-label" for="fileInput">Customer Photo</label>
                                                            <div class="controls">
                                                                <input name="customerPhoto" class="input-file uniform_on" id="fileInput" type="file">
                                                            </div>
							</div>
                                                      
							
                                                      
							          
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Add Customer</button>
							  <button type="reset" class="btn">Cancel</button>
							</div>
						  </fieldset>
						</form>   

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>