<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>


<?php
if(isset($_GET['customerId'])){
 $customerId = $_GET['customerId'];

}

?>


<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $updateCustomer = $customer->updateCustomer($_POST, $_FILES, $customerId);
    }

 ?>

                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Add Customer:</h2>
           <?php 
            if(isset($updateCustomer)){
                echo $updateCustomer;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data" style="background-color: #2D89EF" >
						  <fieldset>
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div>  
                                                      
                                                    <div class="control-group">
                                                      <label class="control-label" for="selectError3">Customer Vallage or Area</label>
                                                      <div class="controls">

                                                          <select name="customerArea" id="selectError3">
                                                              <option>Select</option>
                                                         <?php
                                                          $getAllArea = $customer->getAllArea();
                                                              if($getAllArea){
                                                                  while ($result = $getAllArea->fetch_assoc()){

                                                          ?>
                                                              <option value="<?php echo $result['areaName']; ?>"><?php echo $result['areaName']; ?></option>
                                                           <?php } } ?>       

                                                        </select>
                                                             
                                                          
                                                      </div>
                                                   </div> 
                                                     <?php
                                                     $getCustomerById = $customer->getCustomerById($customerId);
                                                     
                                                     if($getCustomerById){
                                                         while ($result = $getCustomerById->fetch_assoc()){
                                                             
                                                    
                                                     ?> 
                                                      
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">Name</label>
							  <div class="controls">
                                                              <input type="text" name="CustomerName" value="<?php echo $result['CustomerName']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                        </div> 

							<div class="control-group">
							  <label class="control-label" for="typeahead">Father's Name</label>
							  <div class="controls">
                                                              <input type="text" name="cusfatherName" value="<?php echo $result['cusfatherName']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Mother's Name</label>
							  <div class="controls">
                                                              <input type="text" name="cusmotherName" value="<?php echo $result['cusmotherName']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Village</label>
							  <div class="controls">
                                                              <input type="text" name="cusvillage" value="<?php echo $result['cusvillage']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Post</label>
							  <div class="controls">
                                                              <input type="text" name="cuspost" value="<?php echo $result['cuspost']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Thana</label>
							  <div class="controls">
                                                              <input type="text" name="custhana" value="<?php echo $result['custhana']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                        <div class="control-group">
							  <label class="control-label" for="typeahead">District</label>
							  <div class="controls">
                                                              <input type="text" name="cusDistrict" value="<?php echo $result['cusDistrict']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                    <div class="control-group">
                                                      <label class="control-label" for="selectError3">Gender</label>
                                                      <div class="controls">
                                                          <select name="cusgender" id="selectError3">
                                                              <option>Select</option>
                                                              <option value="Male">Male</option>
                                                              <option value="Female">Female</option>
                                                              

                                                        </select>
                                                      </div>
                                                   </div> 
                                                      
                                                      
                                                       <div class="control-group">
							  <label class="control-label" for="typeahead">Nid or Birth Reg</label>
							  <div class="controls">
                                                              <input type="text" name="cusnid" value="<?php echo $result['cusnid']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Mobile Number</label>
							  <div class="controls">
                                                              <input type="text" name="cusmobileNumber" value="<?php echo $result['cusmobileNumber']; ?>" class="span4 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         
                                                        <div class="control-group">
							  <label class="control-label" for="typeahead">Joining Date</label>
							  <div class="controls">
                                                              <input type="text" name="cusJoinDate" value="<?php echo $result['cusJoinDate']; ?>" class="span4 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                      
                                                       <div class="control-group">
							  <label class="control-label">Date of Birth</label>
							  <div class="controls">
                                                              <input type="text" name="cusdateOfBirth" value="<?php echo $result['cusdateOfBirth']; ?>">
							  </div>
							</div> 
                                                      
                                                      
                                    
                                                          

                                                        <div class="control-group">
                                                            <label class="control-label" for="fileInput">Customer Photo</label>
                                                            <div class="controls">
                                                                <input name="customerPhoto" class="input-file uniform_on" id="fileInput" type="file">
                                                            </div>
							</div>
                                                      
                                                  
                                                      
							          
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Update Customer</button>
							  <button type="reset" class="btn">Cancel</button>
							</div>
						  </fieldset>
						</form>   

					</div>
   <?php } } ?>








				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>