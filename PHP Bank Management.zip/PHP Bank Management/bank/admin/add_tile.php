<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $addtitle = $front->addtitle($_POST);
    }

 ?>

<style>
    .addtitle{
        width: 650px;
        height: 200px
    }
</style>
                    
<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Add title:</h2>
           <?php 
            if(isset($addtitle)){
                echo $addtitle;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data" style="background-color: #2D89EF">
						  <fieldset>
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div> 
                                        
                                                    
                                                      
                                                      <div class="control-group">
							  <label class="control-label" for="typeahead">Add Title </label>
							  <div class="controls">
                                                              <input type="text" name="title" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                       </div>
                                                      
                                                       <div class="control-group">
							  <label class="control-label" for="typeahead">Footer title </label>
							  <div class="controls">
                                                              <input type="text" name="ftitle" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                       </div>
                                                      

                                                    

							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Add Title</button>
							  
							</div>
						  </fieldset>
						</form>   

					</div>
		
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>