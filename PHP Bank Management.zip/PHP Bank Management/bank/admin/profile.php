<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php 
  if(isset($_GET['adminId'])||$_GET['adminId']==NULL){
     $id = $_GET['adminId'];
     
     $userById = $usr->getUserById($id);
  }
?>
                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" > User Profile:</h2>
         
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                            <table border="2" class="table1" style="width:100%">
                                                <?php 
                                                    if($userById){
                                                        while($result = $userById->fetch_assoc()){?>
                                                

                                                
                                                <tr>
                                                  <th style="width:30%"><a href="edit.php?editUser=<?php echo $result['adminId']; ?>">Edit Profile</a></th>
                                                  <th style="width:40%">Customer Details</th>
                                                  <th style="width:30%">Photo</th>
                                                </tr>
                                                <tr>
                                                  <td>User Id</td>
                                                  <td><?php echo $result['adminId']; ?></td>
                                                  <td rowspan="6" bgcolor="#E3F2E1"><img src="<?php echo $result['image']; ?>" class="img-responsive img-rounded" alt="Responsive image"/></td>
                                                </tr>
                                                <tr>
                                                  <td>User Name</td>
                                                  <td><?php echo $result['userName']; ?></td>
                                                 
                                                </tr>
                                                
                                                  <tr>
                                                  <td>Name</td>
                                                  <td><?php echo $result['adminName']; ?></td>
                                                 
                                                </tr>
                                                
                                                <tr>
                                                  <td>Mobile</td>
                                                  <td><?php echo $result['mobile']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Joinning Date</td>
                                                  <td><?php echo $result['date'] ; ?></td>
                                                 
                                                </tr>
                                                
                                                <tr>
                                                  <td>Role</td>
                                                  <td><?php echo $result['adminRole']; ?></td>
                                                  
                                                </tr>
                                                
                                                    <?php } } ?>
                                              </table> 
                                          

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>