
<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>





<?php
if(isset($_GET['depositid'])){
    $depositid = $_GET['depositid'];
}
?>


          
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Fix deposit lift list:</h2>
         
		<div class="row-fluid">
			
					<div class="box-content">
                                           
                                          
                                            
                                           <table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Lift Amount</th>
								  <th>Date</th>
								  
							  </tr>
						  </thead> 
                                                  
                                           <?php
                                             $getfixdepositlift = $fixedDeposit->getfixdepositlift ($depositid);
                                             if($getfixdepositlift){
                                                 while($result = $getfixdepositlift->fetch_assoc()){
                                        
                                            ?>   
                                                  
                                                  
						  <tbody>
							<tr>
                                                            <td><?php echo $result['Profit_amount']; ?></td>
						            <td class="center"><?php echo $fm->formatDate($result['lift_date']); ?></td>
					
							</tr>
							
						  </tbody>
                                                  
                                             <?php } } ?>       
                                                  
					  </table>
                                            

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>