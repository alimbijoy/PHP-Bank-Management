<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['delUser'])){
    $id = $_GET['delUser'];
    $delUser = $usr->delUser($id);
}elseif (isset($_GET['finishCustomer'])) {
    $finish = $_GET['finishCustomer'];
    $finishbyid = $loan->finishbyid($finish);
}elseif (isset($_GET['deleteCustomer'])) {
    $deleteid = $_GET['deleteCustomer'];
    $deletecustomer = $loan->deletecustomer($deleteid);
}elseif (isset($_GET['activeCustomer'])) {
   $activeCustomerid = $_GET['activeCustomer'];
   $activeCustomer = $loan->activeCustomerr($activeCustomerid);
}

?>
          
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Customer List:</h2>
         
		<div class="row-fluid">
			
					<div class="box-content">
                                           
                                          
                                            
                                           <table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Customer Name</th>
								  <th>Joining Date</th>
								  <th>Father</th>
                                                                  <th>Village</th>
                                                                  <th>Mobile</th>
								  <th>Customer Id</th>
								  <th>Actions</th>
							  </tr>
						  </thead> 
                                                  
                                           <?php
                                             $getAllCustomer = $customer->getAllCustomer();
                                             if($getAllCustomer){
                                                 while($result = $getAllCustomer->fetch_assoc()){
                                                $customerId = $result['customerId'];
                                                Session::set('customerId', $customerId);
                                            ?>   
                                                  
                                                  
						  <tbody>
							<tr>
                                                                
								<td class="center"><?php echo $result['CustomerName']; ?></td>
                                                                <td class="center"><?php echo $result['cusJoinDate']; ?></td>
								<td class="center"><?php echo $result['cusfatherName']; ?></td>
                                                                <td class="center"><?php echo $result['cusvillage']; ?></td>
                                                                <td class="center"><?php echo $result['cusmobileNumber']; ?></td>
                                                                <td class="center"><?php echo $result['customerId']; ?></td>
                                                                
								
								<td class="center">
                                                                    <a class="btn btn-success" href="customer_profile.php?customerId=<?php echo $result['customerId']; ?>">
										<i class="halflings-icon white zoom-in"></i> 
      
									</a>
                                                                    <?php if(Session::get("adminRole") == '1'){ ?>
									<a class="btn btn-info" href="updateCustomer.php?customerId=<?php echo $result['customerId']; ?>">
										<i class="halflings-icon white edit"></i>  
									</a>
									<a onclick="return confirm('Are you sure to Delete !')" class="btn btn-danger" href="?deleteCustomer=<?php echo $result['customerId']; ?>">
										<i class="halflings-icon white trash"></i> 
									</a>
                                                                     <a onclick="return confirm('Are you sure to finished this Customer !')" class="btn btn-danger" href="?finishCustomer=<?php echo $result['customerId']; ?>">Finished</a>
                                                                     
                                                                    <?php } ?> 
                                                                     
                                                                    <?php 
                                                                    $stutas = $loan->stutas($customerId);
                                                                    if($stutas){
                                                                        while ($result = $stutas->fetch_assoc()){

                                                                            if($result['cuslevel'] ==1) { ?>
                                                                     
                                                                         <a class="btn btn-success" href="?activeCustomer=<?php echo Session::get("customerId"); ?>">Active</a>	
                                                                   
                                                                    <?php  }} }  ?>
							            
								 
                                                                    
                                                                    
								</td>
							</tr>
							
						  </tbody>
                                                  
                                             <?php } } ?>       
                                                  
					  </table>
                                            

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>