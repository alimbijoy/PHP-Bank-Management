<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>




<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $balnceuttolon = $profit->balnceuttolon($_POST);
    }

 ?>

                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Balnce lift:</h2>
           <?php 
            if(isset($balnceuttolon)){
                echo $balnceuttolon;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST"  style="background-color: #2D89EF">
						  <fieldset>
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div> 
                                                      
                                                      
                                                      
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead"> Enter Balnce Amount</label>
							  <div class="controls">
                                                              <input type="text" name="uttolon" class="span2 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                       </div>
                                                      

							          
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Balnce lift</button>
							     
							</div>
                                                       
						  </fieldset>
						</form>   

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>