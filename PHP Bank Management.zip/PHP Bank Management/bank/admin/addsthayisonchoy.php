<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['customerId'])){
    $customerId = $_GET['customerId'];

}

?>


<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $addNomonichoy = $customer->addNomonichoy($_POST, $customerId);
    }

 ?>

                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Add permanent saving:</h2>
           <?php 
            if(isset($addNomonichoy)){
                echo $addNomonichoy;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST"  style="background-color: #2D89EF">
						  <fieldset>
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div> 
                                                      
                                                      
                                                      
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">Duration  </label>
							  <div class="controls">
                                                              <input type="text" name="duration" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                       </div>
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">payment</label>
							  <div class="controls">
                                                              <input type="text" name="aday" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">profit</label>
							  <div class="controls">
                                                              <input type="text" name="munafa" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                          

							<div class="control-group">
							  <label class="control-label" for="typeahead">Total </label>
							  <div class="controls">
                                                              <input type="text" name="inTotal" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
  
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Add </button>
							     
							</div>
                                                       
						  </fieldset>
						</form>   

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>