


<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>



<?php
 if(!isset($_GET['customerId'])||$_GET['customerId']==NULL){
   echo "<script>window.location='customer_list.php';</script>";   
         
} else {
  $id = $_GET['customerId'];  
  $customer->deleteloanById($id);    
}

?>
                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">
    <h1 style="color: #FE2E2B">Loan delete successfully!</h1>
     <a class="btn btn-primary" href="customer_list.php">Back to customers list </a>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>