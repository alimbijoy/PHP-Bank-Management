<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['customerId'])){
    $customerId = $_GET['customerId'];

}
?>


<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $updateloan = $loan->updateLoan($_POST, $customerId);
    }

 ?>

                 
                        
			<!-- start: Content -->
          <div id="content" class="span10" style="background-color: #4B15BE" >			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" > Update Loan:</h2>
           <?php 
            if(isset($updateloan)){
                echo $updateloan;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content" >
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST"  style="background-color: #2D89EF">
						  <fieldset>
                                                <?php
                                                  $selectLoanbayid = $loan->selectLoanbayid($customerId);
                                                   if($selectLoanbayid){
                                                       while ($result = $selectLoanbayid->fetch_assoc()){
                                                           
                                                  
                                                   ?>           
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div>    
                                                
                                                  <div class="control-group">
                                                      <label class="control-label" for="selectError3">Type of loan</label>
                                                      <div class="controls">
                                                          <select name="loanType" id="selectError3">
                                                              <option>Select</option>
                                                              <option value="Daily">Daily</option>
                                                              <option value="Weekly">Weekly</option>
                                                              <option value="Monthly">Monthly</option>
                                                              <option value="Yearly">Yearly</option>

                                                        </select>
                                                      </div>
                                                   </div>  
                                              
                                                      
                                                      
                                                      
						  <div class="control-group">
                                                         
							  <label class="control-label" for="typeahead">Amount</label>
							  <div class="controls">
                                                              <input type="text" name="amount" value="<?php echo $result['amount']; ?>" class="span3 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> Loan Number
                                                              <input type="text" name="loanNumbber" value="<?php echo $result['loanNumbber']; ?>" class="span3 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 

								<p class="help-block"></p>
							  
							  </div>
                                                     </div>    
                                            
                                                          
                                                          

							<div class="control-group">
							  <label class="control-label" for="typeahead">Profit</label>
							  <div class="controls">
                                                              <input type="text" name="munafa" value="<?php echo $result['munafa']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                      
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">In Total</label>
							  <div class="controls">
                                                              <input type="text" name="inTotal" value="<?php echo $result['inTotal']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Date</label>
							  <div class="controls">
                                                              <input type="text" name="startDate" value="<?php echo $result['startDate']; ?>" >To 
                                                              <input type="text" name="endDate"  value="<?php echo $result['endDate']; ?>"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                               
                                                          
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Payment</label>
							  <div class="controls">
                                                              <input type="text" name="kisti" value="<?php echo $result['kisti']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                        <div class="control-group">
							  <label class="control-label" for="typeahead">Total payment</label>
							  <div class="controls">
                                                              <input type="text" name="totalKisti" value="<?php echo $result['totalKisti']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Loan insurance</label>
							  <div class="controls">
                                                              <input type="text" name="loanBima" value="<?php echo $result['loanBima']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                        <div class="control-group">
							  <label class="control-label" for="typeahead">Granted Name</label>
							  <div class="controls">
                                                              <input type="text" name="grantedName" value="<?php echo $result['grantedName']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Granted Mobile Number</label>
							  <div class="controls">
                                                              <input type="text" name="grantedMobile" value="<?php echo $result['grantedMobile']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                       <div class="control-group">
							  <label class="control-label" for="typeahead">Relation</label>
							  <div class="controls">
                                                              <input type="text" name="relation" value="<?php echo $result['relation']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                             
       
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Update Loan</button>
							  <button type="reset" class="btn">Cancel</button>
							</div>
                                                        <?php } } ?>      
						  </fieldset>
						</form>   

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>