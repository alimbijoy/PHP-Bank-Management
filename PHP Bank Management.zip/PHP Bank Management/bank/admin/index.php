<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php


spl_autoload_register(function($class){
  include "function/".$class.".php";
});

?>






<?php include 'inc/dasboardfunction.php'; ?>


	
			
  <!-- start: Content -->
 <div id="content" class="span10">
     
     <?php if(Session::get("adminRole") == '1'){ ?>
     
               <a style="margin-bottom: 10px; " class="btn btn-primary" href="addBalnce.php">Add balance</a>
               <a style="margin-bottom: 10px; " class="btn btn-primary" href="balanceUttolon.php">Blance lifed</a>
               <a style="margin-bottom: 10px; " class="btn btn-primary" href="cost.php">Add Cost</a>
               <a style="margin-bottom: 10px; " class="btn btn-primary" href="addRinbima.php">Add loan insurance</a>
               <a style="margin-bottom: 10px; " class="btn btn-primary" href="rinbima_uttolon.php">Loan insurance lifed</a>
               <a style="margin-bottom: 10px; " class="btn btn-primary" href="allsearch.php">Search</a>
                            

                            
                            
                        <!--	Start-->
			<div class="row-fluid">
                   
                            <table border="2" class="table1" style="width:100%; margin: 5px;">
     
                                                <tr>
                                                
                                                      <td colspan="4" style="text-align: center;  background: #94AD47"> Balace and cost information</td>
                                                    
                                                </tr>
                                    
                                                <tr>
                                                  <td width="12.5%">Balace</td>
                                                  <td width="12.5%"><?php echo Session::get("balncesthity"); ?></td>
                                                  
                                                  <td width="12.5%">Total Cost</td>
                                                  <td width="12.5%"><?php echo Session::get("cost"); ?></td>
                                                  
                                                </tr>
 
                                              </table>   

			</div>
                     <!--		end-->
                                                         
                            
                       
                   
                            
                            
                            
                  <!--	Start-->
			<div class="row-fluid">
                   
                            <table border="2" class="table1" style="width:100%; margin: 5px;">
     
                                                  <tr>
                                                
                                                      <td colspan="6" style="text-align: center;  background: #42ABE8"> Loan saving information</td>
                                                    
                                                </tr>
                                             
                                                
                                                
                                                
                                                <tr>
                                                  <td width="16.66%">Total loan</td>
                                                  <td width="16.66%"><?php echo  Session::get("getTotall"); ?> Tk</td>
                                                  <td width="16.66%">Total payment</td>
                                                  <td width="16.66%"><?php echo Session::get("getTotallAday"); ?> Tk</td>
                                                  <td width="16.66%">Payment remaining</td>
                                                  <td width="16.66%"><?php echo round(Session::get("reamainin")); ?> Tk</td>
                                                </tr>
                                                
                                                 <tr>
                                                  <td>Total profit</td>
                                                  <td> <?php echo Session::get("getTotalProfit"); ?> Tk</td>
                                                 
                                                  <td>Profit payment</td>
                                                  <td> <?php echo round(Session::get("persent")); ?> Tk</td>
                                                  <td>Profit status</td>
                                                  <td> <?php echo round(Session::get("profitSthiti")); ?> Tk</td>
<!--                                                   <td> //<?php // echo Session::get("profitSthiti"); ?> Tk</td>-->
                                                </tr>
                                                
                                               <tr>
                                                  <td>Total loan insurance</td>
                                                  <td> <?php echo Session::get("loanBima"); ?> Tk</td>
                                                 
                                                  <td>Loan insurance lifed</td>
                                                  <td> <?php echo Session::get("rinbimautto"); ?> Tk</td>
                                                  <td>Loan insurance status</td>
                                                  <td> <?php echo Session::get("rinbimasthyty"); ?> Tk</td>
                                                </tr>   
                                                
                                                
                                                
<!--                                         for general saving start      -->
                                                
                                                <tr>
                                                  <td>General saving intotal</td>
                                                  <td> <?php echo Session::get("getGNtotal"); ?> Tk</td>
                                                  <td>General saving lifet</td>
                                                  <td> <?php echo Session::get("getGNuttolon"); ?> Tk</td>
                                                  <td>General saving status</td>
                                                  <td> <?php echo Session::get("gnTotal"); ?> Tk</td>
                                                </tr>
                                             
                                           <?php
                                           $getgnstotalprofit = $customer->getgnstotalprofit();
                                           if($getgnstotalprofit){
                                               while ($result = $getgnstotalprofit->fetch_assoc()){
                                                $tprofit = $result['sum(profit)'];
                                                 Session::set('tprofit', $tprofit);
                                            }
                                           
                                         }
                                         
                                         $getgnstotalprofitlift = $customer->getgnstotalprofitlift();
                                              if($getgnstotalprofitlift){
                                               while ($result = $getgnstotalprofitlift->fetch_assoc()){
                                                $tprofitlift = $result['sum(gnprofit)'];
                                                 Session::set('tprofitlift', $tprofitlift);
                                            }
                                           
                                         }
                                         
                                         $tprofitstatus = $tprofit-$tprofitlift;
                                          Session::set('tprofitstatus', $tprofitstatus);
                                           ?>     
                                                
                                                
                                                
                                                <tr>
                                                  <td>General saving total profit</td>
                                                  <td> <?php echo Session::get("tprofit"); ?> Tk</td>
                                                  <td>General saving profit lifet</td>
                                                  <td> <?php echo Session::get("tprofitlift"); ?> Tk</td>
                                                  <td>General saving profit status</td>
                                                  <td> <?php echo Session::get("tprofitstatus"); ?> Tk</td>
                                                </tr>
                                                  
<!--                                              general saving end -->
                                                
<!--                                                 perment saving start-->






                                                 <tr>
                                                  <td> Perment saving intotal</td>
                                                  <td> <?php echo Session::get("getSthayiSonchoy"); ?> Tk</td>
                                                  <td>perment saving lifed</td>
                                                  <td> <?php echo Session::get("sthayiSonchoyUttolon"); ?> Tk</td>
                                                  <td>perment saving status </td>
                                                  <td> <?php echo Session::get("sthconchoySthiti"); ?> Tk</td>
                                                </tr> 
                          <?php
                            $getpstotalprofit = $customer->getpstotalprofit();
                            if($getpstotalprofit){
                                while ($result = $getpstotalprofit->fetch_assoc()){
                                 $tpsprofit = $result['sum(psprofit)'];
                                  Session::set('tpsprofit', $tpsprofit);
                             }

                          }

                          $getpstotalprofitlift = $customer->getpstotalprofitlift();
                               if($getpstotalprofitlift){
                                while ($result = $getpstotalprofitlift->fetch_assoc()){
                                 $tpsrofitlift = $result['sum(psprofit)'];
                                  Session::set('tpsrofitlift', $tpsrofitlift);
                             }

                          }

                          $tpsprofitstatus = $tpsprofit-$tpsrofitlift;
                           Session::set('tpsprofitstatus', $tpsprofitstatus);
                            ?>  
                                             
                                                
                                                <tr>
                                                  <td> Perment saving profit intotal</td>
                                                  <td> <?php echo Session::get("tpsprofit"); ?> Tk</td>
                                                  <td>perment saving profit lifed</td>
                                                  <td> <?php echo Session::get("tpsrofitlift"); ?> Tk</td>
                                                  <td>perment saving profit status </td>
                                                  <td> <?php echo Session::get("tpsprofitstatus"); ?> Tk</td>
                                                </tr> 
     <!--                                                 perment saving end-->  
     
<!--                         dps  start                     -->
                                   

                                                <tr>
                                                  <td>Deposit Protection Scheme intotal</td>
                                                  <td> <?php echo Session::get("getAllBima"); ?> || <?php echo Session::get("getdpsone"); ?>  Tk</td>
                                                  <td>DPS lifed</td>
                                                  <td> <?php echo Session::get("getAllBimaUttolon"); ?> Tk</td>
                                                  <td>DPS status</td>
                                                  <td> <?php echo Session::get("bimasthyti"); ?> Tk</td>
                                                </tr>
                              <?php 
                                $getDpsTotalProfit = $customer->getDpsTotalProfit();
                                if($getDpsTotalProfit){
                                    while ($result = $getDpsTotalProfit->fetch_assoc()){
                                      $dpsprofitt = $result['sum(profit)'];
                                     
                                $getDpsLiftProfit = $customer->getDpsLiftProfit();
                                if($getDpsLiftProfit){
                                    while($row = $getDpsLiftProfit->fetch_assoc()){
                                      $dpsprofitLift = $row['sum(profit_lift)'];
                                       $netprofit = $dpsprofitt+$dpsprofitLift;
                                      
                                       Session::set('netprofit', $netprofit);
                                  
                                ?>
                               
                                                
                                                
                                                
                   
                                                 <tr>
                                                  <td>DPS profit intotal</td>
                                                  <td> <?php echo Session::get("netprofit"); ?>  Tk</td>
                                                  <td>DPS profit lift</td>
                                                  <td> <?php echo $dpsprofitLift; ?> Tk</td>
                                                  <td>DPS profit status</td>
                                                  <td> <?php echo $dpsprofitt; ?> Tk</td>
                                                </tr>
                                                
                                <?php } } } } ?>               
      <!--                         dps   end                    -->                                          
                                                
                                               
         
                                              </table>   

				
			</div>
                     <!--		end-->
                    
                     
         
                     
                  <!--	Start-->
			<div class="row-fluid">
                   
                            <table border="2" class="table1" style="width:100%; margin: 5px;">
     
                                                <tr>
                                                
                                                      <td colspan="10" style="text-align: center;  background: #FF9800">Information of loan customers  </td>
                                                    
                                                </tr>
                                    
                                                <tr>
                                                  <td width="10%">Daily Sort Time</td>
                                                  <td width="10%"><?php echo Session::get("daily"); ?></td>
                                                  <td width="10%">Daily Long Time</td>
                                                  <td width="10%"><?php echo Session::get("dailyLongTimecusto"); ?></td>
                                                  <td width="10%">Weekly </td>
                                                  <td width="10%"><?php echo Session::get("weekly"); ?></td>
                                                  <td width="10%">Monthly</td>
                                                  <td width="10%"><?php echo Session::get("monthly"); ?></td>
                                                  <td width="10%">Total </td>
                                                  <td width="10%"><?php echo Session::get("total"); ?></td>
                                                </tr>
 
                                              </table>   

			</div>
                  
                      <!--	Start-->
			<div class="row-fluid">
                   
                            <table border="2" class="table1" style="width:100%; margin: 5px;">
     
                                                <tr>
                                                
                                                      <td colspan="6" style="text-align: center;  background: #DE5448">Deposit Protection Scheme (DPS), General saving and perment saving Customers  Information</td>
                                                    
                                                </tr>
                                    
                                                <tr>
                                                  <td width="16.66%">DPS Customer</td>
                                                  <td width="16.66%"><?php echo Session::get("totalBima"); ?></td>
                                                  <td width="16.66%">General saving Customer</td>
                                                  <td width="16.66%"><?php echo Session::get("gnsaving"); ?></td>
                                                  <td width="16.66%">Perment saving Customer</td>
                                                  <td width="16.66%"><?php echo Session::get("permentsaving"); ?> </td>
                                                </tr>
                                                
                                                
 
                                       </table>  
                            
                            
                            <?php include 'inc/fixeddeposittable.php'; ?>
                            

			</div>
                  
                  
                     <!--		end-->

     <?php } else { ?>
                     <img src="upload/<?php echo Session::get("image"); ?>"/>            
                  
      <h1 style=" color: #FF481F; font-size: 48px;">Welcome to admin panel.</h1>       
      <?php     } ?>

	</div><!--/.fluid-container-->
        
        
        
	<?php include'inc/footer.php'; ?>