<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>





             
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
                    <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Search by date</h2>
           
<div class="box-content">

 <?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['balancee'])){
       $balanceSea = $profit->balanceSearch($_POST);

    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['balanceuttolon'])) {
       $balanceuttolon =  $profit->balanceuttolon($_POST);
       
    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['kistiaday'])) {
        $totalkistiaday =  $profit->totalkistiaday($_POST);
        
    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['gnsonchoy'])) {
        $gnsonchoyaday =  $profit->gnsonchoyaday($_POST);
        
    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['sthsonchoy'])) {
       $sthsonchoyaday =  $profit->sthsonchoyaday($_POST); 
       
    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['rinbitoron'])) {
        $rinbitoron =  $profit->rinbitoron($_POST); 
        
    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['rinbimaadyy'])) {
       $totalrinbimaaday =  $profit->totalrinbimaaday($_POST);
       
    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['munafa'])) {
       $totalmunafaday =  $profit->totalmunafaday($_POST);
       
    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['cost'])) {
        $cost =  $profit->cost($_POST); 
        
    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['fixdeposit'])) {
       $fixdeposit =  $profit->fixdeposittotal($_POST);
       
    }elseif ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['fixdepositprofit'])) {
      $fixdepositprofitlif =  $profit->fixdepositprofitlif($_POST);   
    }

 ?>
   
    
    
    
    
    
    
 <?php 
   if(isset($balanceSea)){        
    while ($row = $balanceSea->fetch_assoc()){
        $result = $row['SUM(balance)'];
        Session::set('totalbalance', $row['SUM(balance)']);
    } 
}


   if(isset($balanceuttolon)){        
    while ($row = $balanceuttolon->fetch_assoc()){
        $result = $row['SUM(uttolon)'];
        Session::set('totalbalanceuttolon', $row['SUM(uttolon)']);
    } 
}

   if(isset($totalkistiaday)){        
    while ($row = $totalkistiaday->fetch_assoc()){
        $result = $row['SUM(kistiaday)'];
        Session::set('totalkistiaday', $row['SUM(kistiaday)']);
    } 
}


   if(isset($gnsonchoyaday)){        
    while ($row = $gnsonchoyaday->fetch_assoc()){
        $result = $row['SUM(gnsonchoyaday)'];
        Session::set('gnsonchoydadayy', $row['SUM(gnsonchoyaday)']);
    } 
}



   if(isset($sthsonchoyaday)){        
    while ($row = $sthsonchoyaday->fetch_assoc()){
        $result = $row['SUM(sthayiaday)'];
        Session::set('sthsonchoydadayy', $row['SUM(sthayiaday)']);
    } 
}


   if(isset($rinbitoron)){        
    while ($row = $rinbitoron->fetch_assoc()){
        $result = $row['SUM(amount)'];
        Session::set('rinbitoronn', $row['SUM(amount)']);
    } 
}


   if(isset($totalrinbimaaday)){        
    while ($row = $totalrinbimaaday->fetch_assoc()){
        $result = $row['SUM(rinBima)'];
        Session::set('rinbimaadayy', $row['SUM(rinBima)']);
    } 
}


   if(isset($totalmunafaday)){        
    while ($row = $totalmunafaday->fetch_assoc()){
        $result = $row['SUM(munafa)'];
        Session::set('munafaaday', $row['SUM(munafa)']);
    } 
}

  if(isset($cost)){        
    while ($row = $cost->fetch_assoc()){
        $result = $row['SUM(cost)'];
        Session::set('costt', $row['SUM(cost)']);
    } 
}

  if(isset($fixdeposit)){        
    while ($row = $fixdeposit->fetch_assoc()){
        $result = $row['SUM(amount)'];
        Session::set('fixamount', $row['SUM(amount)']);
    } 
}


  if(isset($fixdepositprofitlif)){        
    while ($row = $fixdepositprofitlif->fetch_assoc()){
        $result = $row['SUM(Profit_amount)'];
        Session::set('fixprofitd', $row['SUM(Profit_amount)']);
    } 
}


  
 ?>  
    
    
    

 
    <form action="" method="POST">
    <table style="border: 1px solid #000"> 
          <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> Total Balance  <input style="background: #C6EC50" type="text" name="balancestart" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50" type="text" name="balanceEnd" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("totalbalance"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="balancee">Search</button> </td> 
         </tr>
    </table>      
     </form>
  
     <form action="" method="POST">
    <table style="border: 1px solid #000"> 
          <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> Balance lift <input style="background: #C6EC50" type="text" name="balanceuttolonstart" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50" type="text" name="balanceuttolonEnd" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("totalbalanceuttolon"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="balanceuttolon">Search</button> </td> 
         </tr>
    </table>      
     </form>
    
     
  <form action="" method="POST">
    <table  style="border: 1px solid #000;"> 
           <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> payment  <input style="background: #C6EC50" type="text" name="kistyAdaytart" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50"  type="text" name="kistyAdayEnd" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("totalkistiaday"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="kistiaday">Search</button> </td> 
         </tr>
    </table>      
     </form>
    
    
   
   <form action="" method="POST">
    <table style="border: 1px solid #000"> 
           <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> General saving  <input style="background: #C6EC50" type="text" name="gnsonchoystart" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50"  type="text" name="gnsochoyend" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("gnsonchoydadayy"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="gnsonchoy">Search</button> </td> 
         </tr>
    </table>      
    </form>
    
    
   <form action="" method="POST">
    <table style="border: 1px solid #000"> 
           <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> Permanent saving  <input style="background: #C6EC50" type="text" name="sthsonchoystart" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50"  type="text" name="sthsonchoyend" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("sthsonchoydadayy"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="sthsonchoy">Search</button> </td> 
         </tr>
    </table>      
    </form>
     
    <form action="" method="POST">
    <table style="border: 1px solid #000"> 
           <tr>
          <td style=" width: 40%; padding: 5px; margin: 0">Total payment  <input style="background: #C6EC50" type="text" name="rinbitornstart" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50"  type="text" name="rinbitornend" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("rinbitoronn"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="rinbitoron">Search</button> </td> 
         </tr>
    </table>      
    </form> 
    
    <form action="" method="POST">
    <table style="border: 1px solid #000"> 
           <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> Payment deposit<input style="background: #C6EC50" type="text" name="rinbimaadaystart" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50"  type="text" name="rinbimaadayend" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("rinbimaadayy"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="rinbimaadyy">Search</button> </td> 
         </tr>
    </table>      
    </form> 
     
    
    <form action="" method="POST">
    <table style="border: 1px solid #000"> 
           <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> Profit <input style="background: #C6EC50" type="text" name="munafastart" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50"  type="text" name="munafaend" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("munafaaday"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="munafa">Search</button> </td> 
         </tr>
    </table>      
    </form> 
     
    
   <form action="" method="POST">
    <table style="border: 1px solid #000"> 
           <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> Total Cost <input style="background: #C6EC50" type="text" name="coststart" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50"  type="text" name="costend" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("costt"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="cost">Search</button> </td> 
         </tr>
    </table>      
    </form> 
    
    <form action="" method="POST">
    <table style="border: 1px solid #000"> 
           <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> Fixed deposit <input style="background: #C6EC50" type="text" name="fixdeposit_start" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50"  type="text" name="fixdeposit_end" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("fixamount"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="fixdeposit">Search</button> </td> 
         </tr>
    </table>      
    </form> 
    
    <form action="" method="POST">
    <table style="border: 1px solid #000"> 
           <tr>
          <td style=" width: 40%; padding: 5px; margin: 0"> Fixed dps p lift <input style="background: #C6EC50" type="text" name="fixdepositpro_start" placeholder="Enter Starting Date">To </td> 
          <td width="25%"> <input style="background: #C6EC50"  type="text" name="fixdepositpro_end" placeholder="Enter Ending Date">  </td>     
          <td  width="25%"> <input ‍ type="text" value="<?php echo Session::get("fixprofitd"); ?>"> </td>        
          <td width="10%"> <button type="submit" name="fixdepositprofit">Search</button> </td> 
         </tr>
    </table>      
    </form> 

 </div>
 
   <!--           end-->            
                

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>